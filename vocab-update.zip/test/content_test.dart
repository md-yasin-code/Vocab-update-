import 'package:flutter_test/flutter_test.dart';
import 'package:deutsch_bangla/data/extended_lessons.dart';
import 'package:deutsch_bangla/data/seed_data.dart';
import 'package:deutsch_bangla/data/extended_vocabulary.dart';
import 'package:deutsch_bangla/data/additional_vocabulary.dart';
import 'package:deutsch_bangla/data/spreadsheet_vocabulary.dart';
import 'package:deutsch_bangla/data/vocabulary_quiz_seed.dart';

void main() {
  test('Bundled A1-B2 curriculum seed is populated', () {
    final words = buildExtendedVocabulary();
    expect(words.length, 100);
    expect(additionalVocabularySeed.length, 40);
    expect(extendedLessonSeed.length, 26);
    expect(buildVocabularyQuizSeed().length, 140);
    expect(buildAdditionalVocabularyQuizSeed().length, 40);
    expect(words.map((word) => word['level']).toSet(), containsAll(['A1', 'A2', 'B1', 'B2']));
  });

  // The spreadsheet bank grows whenever new rows are added to
  // assets/data/vocabulary_master.csv, so these checks never hard-code its size.
  test('Spreadsheet vocabulary is consistent and duplicate free', () {
    final allWords = <String>[
      ...vocabularySeed.map((row) => (row['german'] as String).replaceFirst(RegExp(r'^(der|die|das) '), '')),
      ...buildExtendedVocabulary().map((row) => row['german'] as String),
      ...additionalVocabularySeed.map((row) => row['german'] as String),
      ...spreadsheetVocabularySeed.map((row) => row['german'] as String),
    ].map((word) => word.toLowerCase()).toList();
    expect(allWords.toSet().length, allWords.length, reason: 'duplicate German headwords');
    expect(spreadsheetVocabularySeed.length, greaterThanOrEqualTo(43));
    for (final row in spreadsheetVocabularySeed) {
      expect(['A1', 'A2', 'B1', 'B2'], contains(row['level']));
      for (final key in ['german', 'article', 'plural', 'pronunciation', 'meaning_bn', 'example_de', 'example_bn', 'word_type']) {
        expect((row[key] as String).trim(), isNotEmpty, reason: '${row['german']} is missing $key');
      }
    }
  });

  test('Spreadsheet quiz questions match the vocabulary and have valid options', () {
    final quiz = buildSpreadsheetVocabularyQuizSeed();
    expect(quiz.length, spreadsheetVocabularySeed.length);
    for (final question in quiz) {
      final options = (question['options'] as String).split('|');
      expect(options.toSet().length, options.length, reason: 'duplicate quiz options');
      expect(options, contains(question['answer']));
    }
  });
}
